The folder contains general tools needed to operate the GCS. like the driver for the radio trasmitter or driver for easyCap.

Tal.
